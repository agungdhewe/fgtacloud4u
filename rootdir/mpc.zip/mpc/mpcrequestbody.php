<?php namespace TransFashion\MPC;




class MPCRequestBody {
	private $_transactionNo;
	private $_data;

	function __construct($data) {
		$this->_transactionNo = MPCHelper::GenerateTransactionNo();
		$this->_data = $data;
	}



}

