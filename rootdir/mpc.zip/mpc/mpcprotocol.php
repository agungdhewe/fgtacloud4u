<?php namespace TransFashion\MPC;


require_once __DIR__ . '/mpchelper.php';
require_once __DIR__ . '/mpcheader.php';
require_once __DIR__ . '/mpcrequestbody.php';
require_once __DIR__ . '/mpcresponse.php';


/**
 * MPC Procotol
 * Untuk core koneksi ke MPC Open API
 * 
 * @package MPCConnector
 * @link https://github.com/kura1420/TFI-MPC
 * @author Abdul Syakur
 * @author Agung Nugroho
 **/
class MPCProtocol {
	
	private object $config;

	function __construct(object $config) {
		$defaultConfig = [
			'Host' => 'http://47.242.35.254:18084/api/v1.0/mpc',
			'ApplicationId' => '',
			'ApplicationSecret' => '',
			'PrivateKey' => ''
		];
		$this->config = (object) array_merge($defaultConfig, (array) $config);		
	}


	function ApiExecute($apiTarget, $data) : MPCResponse {
		try {
			$url = $this->config->Host . '/' . $apiTarget;
			$appid = $this->config->ApplicationId;
			$appsecret = $this->config->ApplicationSecret;
			$privatekey = $this->config->PrivateKey;

			$body = new MPCRequestBody($data);
			$header = new MPCHeader($appid, $appsecret, $privatekey,  $body);

			/* lakukan kirim data ke Open MPC disini */
			$res = $this->SendData($url, $header, $body);

			$result = new MPCResponse($res);


			if ($result->getCode()!=0) {
				throw new \Exception($result->getMessage());
			}

			return $result;
		} catch (\Exception $ex) {
			throw $ex;
		}
	}


	function SendData($url, $header, $body) {
		try {

			$ch = \curl_init(); 
			\curl_setopt($ch, CURLOPT_URL, $url); 
			\curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
			\curl_setopt($ch, CURLOPT_HTTPHEADER, $header->getFormattedData());
			// dst
			// dst
			

			$output = \curl_exec($ch);			
			\curl_close($ch); 
			
			$result = json_decode($output);
			return $result;
		} catch (\Exception $ex) {
			throw $ex;
		}
	}

}





