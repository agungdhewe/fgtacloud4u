<?php namespace TransFashion\MPC;

require_once __DIR__ . '/mpcprofile.php';

/**
 * MPC Interface
 * Untuk keperluan koneksi ke platform MPC CTCOrp
 * 
 * @package MPCConnector
 * @link https://github.com/kura1420/TFI-MPC
 * @author Abdul Syakur
 * @author Agung Nugroho
 **/

interface iMPC {
	
	public function RequestAuthenticationPage() : string;
	public function VerifyTokenId(string $tokenid) : MPCProfile;
	public function AuthorizeTokenId(string $tokenid) : MPCProfile;


	public function GenerateOTP(string $phonenumber, string $scene) : string;
	public function ValidateOTP(string $phonenumber, string $scene, $otpSeqNo, $otp) : bool;


	public function isPhoneNumberExist(string $phonenumber) : bool;
	public function getUserProfile(string $phonenumber) : MPCProfile;



	public function PointAdd(string $phonenumber, float $amount);
	public function PointGetBalance(string $phonenumber) : float;
	public function PointListHistory();


	/*
	public function CouponAcquire(string $phonenumber, string $couponid) : bool;
	public function CouponCalculateAvailable();
	public function CouponGetInstance();
	public function CouponListAquirable();
	public function CouponListAll();
	public function CouponRedeem();
	public function CouponReverseRedeemed();

	public function WalletCreateOrder();
	public function WalletGetBalance();
	*/

}
