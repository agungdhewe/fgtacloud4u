<?php namespace TransFashion\MPC;

class MPCHelper {

	static function CreateNonce($timestamp) {
		$_iter = 10;
		$_hash = 'sha256';
		$_secret = 'maraigendheng';
		$_uid = self::GenerateUid();
		$hash = hash($_hash, $timestamp . $_secret . $_uid);
		$i = 0;
		do{
			$hash = hash($_hash, $hash);
			$i++;
		} while ($i < $_iter);
			return $hash;
	}

	static function GenerateUid() {
		$length = 32;
		if(extension_loaded('openssl')){
			$seed = bin2hex(openssl_random_pseudo_bytes($length));
			return base64_encode($seed);
		}
		for ($i = 0; $i < $length; $i++) {
			$seed .= chr(mt_rand(0, 255));
		}
		return base64_encode($seed);
	}


	static function GenerateTransactionNo() {
		
	}
}
